-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2019 at 02:48 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bendung`
--

-- --------------------------------------------------------

--
-- Table structure for table `data_rekap`
--

CREATE TABLE `data_rekap` (
  `id` int(11) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tinggi_air` float NOT NULL,
  `limpasan_air` float NOT NULL,
  `level` varchar(15) NOT NULL,
  `status_pintu_1` varchar(10) NOT NULL,
  `status_pintu_2` varchar(10) NOT NULL,
  `status_pintu_3` varchar(10) NOT NULL,
  `status_pintu_4` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_rekap`
--

INSERT INTO `data_rekap` (`id`, `waktu`, `tinggi_air`, `limpasan_air`, `level`, `status_pintu_1`, `status_pintu_2`, `status_pintu_3`, `status_pintu_4`) VALUES
(15, '2019-05-08 03:09:18', 17.6, 3.6, 'Bahaya', 'Open', 'Open', 'Close', 'Close'),
(16, '2019-05-08 03:10:02', 18.7, 4.7, 'Awas', 'Open', 'Open', 'Open', 'Open'),
(17, '2019-05-08 03:10:31', 19.8, 5.8, 'Awas', 'Open', 'Open', 'Open', 'Open'),
(18, '2019-05-08 03:11:00', 14.2, 0.2, 'Aman', 'Close', 'Close', 'Close', 'Close'),
(19, '2019-05-08 03:11:45', 17.3, 3.3, 'Siaga', 'Open', 'Close', 'Close', 'Close'),
(20, '2019-05-08 03:12:37', 18.3, 4.3, 'Bahaya', 'Open', 'Open', 'Open', 'Close'),
(21, '2019-05-09 09:00:51', 18.3, 4.3, 'Bahaya', 'Open', 'Open', 'Open', 'Close');

-- --------------------------------------------------------

--
-- Table structure for table `kontrolling`
--

CREATE TABLE `kontrolling` (
  `id` int(10) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pintu_utama` int(2) DEFAULT NULL,
  `pintu_irigasi` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kontrolling`
--

INSERT INTO `kontrolling` (`id`, `waktu`, `pintu_utama`, `pintu_irigasi`) VALUES
(1, '2019-05-09 09:37:39', 3, 'Close');

-- --------------------------------------------------------

--
-- Table structure for table `kota`
--

CREATE TABLE `kota` (
  `id_kota` int(10) NOT NULL,
  `kota` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kota`
--

INSERT INTO `kota` (`id_kota`, `kota`) VALUES
(1, 'Brebes'),
(2, 'Tegal'),
(3, 'Jakarta'),
(4, 'Bandung'),
(5, 'Surabaya'),
(6, 'Yogyakarta'),
(7, 'Bali'),
(8, 'Medan'),
(9, 'Makasar'),
(10, 'Semarang');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `foto` varchar(150) DEFAULT NULL,
  `id_kota` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `password`, `foto`, `id_kota`) VALUES
(1, 'Zihan Sri Tahani', 'zihansritahani@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'IMG20170729175502.jpg', 2),
(2, 'Khafidotun Khasanah', 'khafidotun2@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'alvi (FILEminimizer).jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data_rekap`
--
ALTER TABLE `data_rekap`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kontrolling`
--
ALTER TABLE `kontrolling`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kota`
--
ALTER TABLE `kota`
  ADD PRIMARY KEY (`id_kota`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unik` (`nama`),
  ADD UNIQUE KEY `unik2` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data_rekap`
--
ALTER TABLE `data_rekap`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `kontrolling`
--
ALTER TABLE `kontrolling`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
